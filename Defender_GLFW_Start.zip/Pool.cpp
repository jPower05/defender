// ===============================================
// @file   pool.cpp
// @author kmurphy
// @brief  Specification of memory pool collection class 
// ===============================================

#include <iostream>
#include "Pool.h"


// this file is empty as class implementation was so small that 
// i just put it in its header file.


